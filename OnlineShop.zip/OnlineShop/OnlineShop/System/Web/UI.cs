﻿namespace System.Web
{
    public class UI
    {
    }
}